class Professeur:
    nombre_professeurs = 0

    def __init__(self, prenom, nom, age, matieres):
        self._prenom = prenom
        self._nom = nom
        self._age = age
        self._matieres = matieres
        Professeur.nombre_professeurs += 1

    def afficher_info(self):
        print(f"Professeur: {self._prenom} {self._nom}, {self._age} ans")
        print(f"Matières: {', '.join(self._matieres)}")

    # Getters
    def get_prenom(self):
        return self._prenom

    def get_nom(self):
        return self._nom

    def get_age(self):
        return self._age

    def get_matieres(self):
        return self._matieres

    # Setters
    def set_prenom(self, prenom):
        self._prenom = prenom

    def set_nom(self, nom):
        self._nom = nom

    def set_age(self, age):
        self._age = age

    def set_matieres(self, matieres):
        self._matieres = matieres
