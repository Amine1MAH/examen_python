class Etudiant:
    nombre_etudiants = 0

    def __init__(self, prenom, nom, age, cours):
        self._prenom = prenom
        self._nom = nom
        self._age = age
        self._cours = cours
        Etudiant.nombre_etudiants += 1

    def afficher_info(self):
        print(f"Étudiant: {self._prenom} {self._nom}, {self._age} ans")
        print(f"Cours: {', '.join(self._cours)}")

    # Getters
    def get_prenom(self):
        return self._prenom

    def get_nom(self):
        return self._nom

    def get_age(self):
        return self._age

    def get_cours(self):
        return self._cours

    # Setters
    def set_prenom(self, prenom):
        self._prenom = prenom

    def set_nom(self, nom):
        self._nom = nom

    def set_age(self, age):
        self._age = age

    def set_cours(self, cours):
        self._cours = cours
