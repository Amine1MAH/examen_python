class Directeur:
    nombre_directeurs = 0

    def __init__(self, prenom, nom, poste, annees_experience, departement):
        self._prenom = prenom
        self._nom = nom
        self._poste = poste
        self._annees_experience = annees_experience
        self._departement = departement
        Directeur.nombre_directeurs += 1

    def afficher_info(self):
        print(f"Directeur: {self._prenom} {self._nom}")
        print(f"Poste: {self._poste}")
        print(f"Années d'expérience: {self._annees_experience}")
        print(f"Département: {self._departement}")

    # Getters
    def get_prenom(self):
        return self._prenom

    def get_nom(self):
        return self._nom

    def get_poste(self):
        return self._poste

    def get_annees_experience(self):
        return self._annees_experience

    def get_departement(self):
        return self._departement

    # Setters
    def set_prenom(self, prenom):
        self._prenom = prenom

    def set_nom(self, nom):
        self._nom = nom

    def set_poste(self, poste):
        self._poste = poste

    def set_annees_experience(self, annees_experience):
        self._annees_experience = annees_experience

    def set_departement(self, departement):
        self._departement = departement
