from Etudiant import Etudiant
from Professeur import Professeur
from Prospect import Prospect
from Directeur import Directeur
from Personnel import Personnel
class Main:
    def __init__(self):
        self.etudiants = []
        self.professeurs = []
        self.prospects = []
        self.personnels = []
        self.directeurs = []

    def ajouter_etudiant(self, etudiant):
        self.etudiants.append(etudiant)

    def ajouter_professeur(self, professeur):
        self.professeurs.append(professeur)

    def ajouter_prospect(self, prospect):
        self.prospects.append(prospect)

    def ajouter_personnel(self, personnel):
        self.personnels.append(personnel)

    def ajouter_directeur(self, directeur):
        self.directeurs.append(directeur)

    def afficher_etudiants(self):
        for etudiant in self.etudiants:
            print(etudiant)

    def afficher_professeurs(self):
        for professeur in self.professeurs:
            print(professeur)

    def afficher_prospects(self):
        for prospect in self.prospects:
            print(prospect)

    def afficher_personnels(self):
        for personnel in self.personnels:
            print(personnel)

    def afficher_directeurs(self):
        for directeur in self.directeurs:
            print(directeur)

if __name__ == "__main__":
    application = Main()

    etudiant1 = Etudiant("Pierre", "Dupont", 25, "Informatique", 2021)
    application.ajouter_etudiant(etudiant1)

    professeur1 = Professeur("Paul", "Martin", "Mathématiques", 15, "Sciences")
    application.ajouter_professeur(professeur1)

    prospect1 = Prospect("Nina", "Lacroix", "nina.lacroix@email.com", "0654123456")
    application.ajouter_prospect(prospect1)

    personnel1 = Personnel("Sophie", "Leclerc", "Secrétaire", "Administration")
    application.ajouter_personnel(personnel1)

    directeur1 = Directeur("Henri", "Dubois", "Directeur", 20, "Général")
    application.ajouter_directeur(directeur1)

    application.afficher_etudiants()
    application.afficher_professeurs()
    application.afficher_prospects()
    application.afficher_personnels()
    application.afficher_directeurs()
