class Personnel:
    nombre_personnels = 0

    def __init__(self, prenom, nom, poste, annees_experience):
        self._prenom = prenom
        self._nom = nom
        self._poste = poste
        self._annees_experience = annees_experience
        Personnel.nombre_personnels += 1

    def afficher_info(self):
        print(f"Personnel: {self._prenom} {self._nom}")
        print(f"Poste: {self._poste}")
        print(f"Années d'expérience: {self._annees_experience}")

    # Getters
    def get_prenom(self):
        return self._prenom

    def get_nom(self):
        return self._nom

    def get_poste(self):
        return self._poste

    def get_annees_experience(self):
        return self._annees_experience

    # Setters
    def set_prenom(self, prenom):
        self._prenom = prenom

    def set_nom(self, nom):
        self._nom = nom

    def set_poste(self, poste):
        self._poste = poste

    def set_annees_experience(self, annees_experience):
        self._annees_experience = annees_experience
