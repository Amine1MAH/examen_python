class Prospect:
    nombre_prospects = 0

    def __init__(self, prenom, nom, email, interets):
        self._prenom = prenom
        self._nom = nom
        self._email = email
        self._interets = interets
        Prospect.nombre_prospects += 1

    def afficher_info(self):
        print(f"Prospect: {self._prenom} {self._nom}")
        print(f"Email: {self._email}")
        print(f"Intérêts: {', '.join(self._interets)}")

    # Getters
    def get_prenom(self):
        return self._prenom

    def get_nom(self):
        return self._nom

    def get_email(self):
        return self._email

    def get_interets(self):
        return self._interets

    # Setters
    def set_prenom(self, prenom):
        self._prenom = prenom

    def set_nom(self, nom):
        self._nom = nom

    def set_email(self, email):
        self._email = email

    def set_interets(self, interets):
        self._interets = interets
