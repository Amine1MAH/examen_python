clients = []

# Fonction pour ajouter un client
def ajouter_client():
    nom = input("Nom du client : ")
    adresse = input("Adresse : ")
    telephone = input("Numéro de téléphone : ")
    age = int(input("Âge : "))
    achat = float(input("Montant total des achats : "))
    clients.append({"nom": nom, "adresse": adresse, "telephone": telephone, "age": age, "achat": achat})
    print("Le client a été ajouté avec succès !")

# Fonction pour modifier un client
def modifier_client():
    nom = input("Nom du client à modifier : ")
    for client in clients:
        if client["nom"] == nom:
            client["adresse"] = input("Nouvelle adresse : ")
            client["telephone"] = input("Nouveau numéro de téléphone : ")
            client["age"] = int(input("Nouvel âge : "))
            client["achat"] = float(input("Nouveau montant total des achats : "))
            print("Les informations du client ont été mises à jour !")
            return
    print("Aucun client trouvé avec ce nom.")

# Fonction pour supprimer un client
def supprimer_client():
    nom = input("Nom du client à supprimer : ")
    for client in clients:
        if client["nom"] == nom:
            clients.remove(client)
            print("Le client a été supprimé avec succès !")
            return
    print("Aucun client trouvé avec ce nom.")

# Fonction pour afficher les informations de tous les clients
def afficher_clients():
    print("Liste des clients :")
    for client in clients:
        print(client["nom"], client["adresse"], client["telephone"], client["age"], client["achat"])

# Fonction pour afficher les statistiques globales
def afficher_statistiques():
    nb_clients = len(clients)
    age_moyen = sum([client["age"] for client in clients]) / nb_clients if nb_clients > 0 else 0
    total_achats = sum([client["achat"] for client in clients])
    print("Nombre total de clients :", nb_clients)
    print("Âge moyen des clients :", age_moyen)
    print("Montant total des achats :", total_achats)

# Boucle principale de l'application
while True:
    print("Que voulez-vous faire ?")
    print("1. Ajouter un client")
    print("2. Modifier un client")
    print("3. Supprimer un client")
    print("4. Afficher tous les clients")
    print("5. Afficher les statistiques globales")
    print("6. Quitter")
    choix = input("Entrez le numéro de votre choix : ")
    if choix == "1":
        ajouter_client()
    elif choix == "2":
        modifier_client()
    elif choix == "3":
        supprimer_client()
    elif choix == "4":
        afficher_clients()
    elif choix == "5":
        afficher_statistiques()
    elif choix == "6":
        break
    else:
        print("Choix invalide.")